//
//  HomePage.swift
//  Pulmoro
//
//  Created by Hamza Crichlow on 12/13/24.
//

import SwiftUI

@main
 
struct PulmoroApp: App{
    var body: some Scene {
        WindowGroup {
            TabBar()
        }
    }
}


#Preview {
   
}
